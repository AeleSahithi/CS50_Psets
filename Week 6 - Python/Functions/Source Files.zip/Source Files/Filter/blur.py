from PIL import Image, ImageFilter

before = Image.open(
    "/home/sivan/Computer Science (CS)/CS50/Week 6 - Python/Functions/Filter/images/yard.bmp"
)
after = before.filter(ImageFilter.BoxBlur(10))
after.save("out.bmp")
